package com.example.GameRecommender.models;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class GameGenre {
    String genre;

    public GameGenre(JSONObject jsonObject) throws JSONException {
        genre = jsonObject.getString("name");

        //description = jsonObject.getString("description");
    }
    public GameGenre(){

    }

    public static List<GameGenre> fromJsonArray(JSONArray genreJsonArray) throws JSONException {
        List<GameGenre> gameGenres = new ArrayList<>();
        for(int i=0; i<genreJsonArray.length(); i++)
        {
            gameGenres.add(new GameGenre(genreJsonArray.getJSONObject(i)));
        }
        return gameGenres;
    }

    public String getGenre(){
        return genre;
    }

}
