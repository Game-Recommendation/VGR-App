package com.example.GameRecommender.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.GameRecommender.Post;
import com.example.GameRecommender.PostsAdapter;
import com.example.GameRecommender.R;
import com.codepath.asynchttpclient.AsyncHttpClient;
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler;
import com.example.GameRecommender.Fragments.ComposeFragment;
import com.example.GameRecommender.adapters.VideoGameAdapter;
import com.example.GameRecommender.models.VideoGame;
import com.facebook.stetho.common.ArrayListAccumulator;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Headers;

/**
 * A simple {@link Fragment} subclass.
 */
public class PostsFragment extends Fragment {

    private static final String TAG = "PostsFragment";
    public static int page = 100;
    public static String VIDEO_GAME_URL = "https://api.rawg.io/api/games?page=" + page;
    protected SwipeRefreshLayout swipeContainer;
    protected RecyclerView rvPosts;
    //protectedfinal VideoGameAdapter adapter;
    protected List<Post> allPosts;

    List<VideoGame> videoGames;

    public PostsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_posts, container, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        /*swipeContainer = view.findViewById(R.id.swipeContainer);
        rvPosts = view.findViewById(R.id.rvPosts);
        allPosts = new ArrayList<>();*/


        RecyclerView rvVGames = view.findViewById(R.id.rvVGames);
        videoGames = new ArrayList<>();
        final VideoGameAdapter adapter = new VideoGameAdapter(getContext(), videoGames);

        rvVGames.setAdapter(adapter);
        rvVGames.setLayoutManager(new LinearLayoutManager(getContext()));

        final AsyncHttpClient client = new AsyncHttpClient();
        while (page != 0) {
            client.get(VIDEO_GAME_URL, new JsonHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Headers headers, JSON json) {
                    Log.d(TAG, "onSuccess");
                    JSONObject jsonObject = json.jsonObject;
                    try {
                        JSONArray results = jsonObject.getJSONArray("results");
                        Log.i(TAG, "Results: " + results.toString());
                        videoGames.addAll(VideoGame.fromJsonArray(results));
                        adapter.notifyDataSetChanged();
                        Log.i(TAG, "Video Games: " + videoGames.size());
                    } catch (JSONException e) {
                        Log.e(TAG, "Hit json exception", e);
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Headers headers, String response, Throwable throwable) {
                    Log.d(TAG, "onFailure");
                }
            });
            VIDEO_GAME_URL = "https://api.rawg.io/api/games?page=" + page--;}

        /*swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call swipeContainer.setRefreshing(false)
                // once the network request has completed successfully.
                queryPosts();
            }
        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);*/

        // 1. Create Posts Adapter
        // 2. Create Data Source - Post
        // 3. Set Adapter on Recycler View
        //rvPosts.setAdapter(adapter);
        // 4. Set the layout manager on the recycler view
        //rvPosts.setLayoutManager(new LinearLayoutManager(getContext()));
        //queryPosts();

    }

    /*protected void queryPosts() {
        // What class do I want to query? Posts!
        ParseQuery<Post> query = ParseQuery.getQuery(Post.class);
        query.include(Post.KEY_USER);
        query.setLimit(20);
        query.addDescendingOrder(Post.KEY_CREATED_AT);
        // Now to find the ID(s)
        query.findInBackground(new FindCallback<Post>() {
            @Override
            public void done(List<Post> posts, ParseException e) {
                if(e != null) {
                    Log.e(TAG, "I can't reach the posts!", e);
                    return;
                }
                for (Post post : posts) {
                    Log.i(TAG, "Post: " + post.getCaption() + ", and the user is: " + post.getUser().getUsername());
                }
                //adapter.clear();
                allPosts.addAll(posts);
                adapter.notifyDataSetChanged();
                swipeContainer.setRefreshing(false);
            }
        });
    }*/
}


