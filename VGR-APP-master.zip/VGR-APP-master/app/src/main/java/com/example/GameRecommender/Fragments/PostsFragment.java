package com.example.GameRecommender.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.apache.commons.io.FileUtils;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.GameRecommender.Post;
import com.example.GameRecommender.PostsAdapter;
import com.example.GameRecommender.R;
import com.example.GameRecommender.Fragments.ComposeFragment;
import com.codepath.asynchttpclient.AsyncHttpClient;
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler;
import com.example.GameRecommender.Fragments.ComposeFragment;
import com.example.GameRecommender.adapters.VideoGameAdapter;
import com.example.GameRecommender.models.VideoGame;
import com.facebook.stetho.common.ArrayListAccumulator;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Headers;

/**
 * A simple {@link Fragment} subclass.
 */
public class PostsFragment extends Fragment {

    private static final String TAG = "PostsFragment";
    public static int page = 100;
    //EditText genre2;

    String[] genre = {"action","simulation"};
    public String VIDEO_GAME_URL = "https://api.rawg.io/api/games?page="+page;
    protected SwipeRefreshLayout swipeContainer;
    protected RecyclerView rvPosts;
    //protectedfinal VideoGameAdapter adapter;
    protected List<Post> allPosts;
    EditText etCaption;
    Button btnSubmit;
    Button btnSearch;
    String caption;

    List<VideoGame> videoGames;
    VideoGame videoGame;

    public PostsFragment() {
        // Required empty public constructor
    }

    /*public void setGenre(String genre2){
        genre = genre2;
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_posts, container, false);
    }
    //setGenre(getCaption());
    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //genre2 = view.findViewById(R.id.etCaption);
        RecyclerView rvVGames = view.findViewById(R.id.rvVGames);
        etCaption = view.findViewById(R.id.editText2);
        btnSubmit = view.findViewById(R.id.button4);
        btnSearch = view.findViewById(R.id.button5);


        videoGames = new ArrayList<>();
        final VideoGameAdapter videoGameAdapter = new VideoGameAdapter(getContext(), videoGames);
        rvVGames.setAdapter(videoGameAdapter);
        rvVGames.setLayoutManager(new LinearLayoutManager(getContext()));

        final AsyncHttpClient client = new AsyncHttpClient();
        //while (page != 0) {

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                caption = etCaption.getText().toString();
                VIDEO_GAME_URL = "https://api.rawg.io/api/games?genres=" + caption + "&page=" + page;
               /* while (page != 0){
                    client.get(VIDEO_GAME_URL, new JsonHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, Headers headers, JSON json) {
                            Log.d(TAG, "onSuccess");
                            JSONObject jsonObject = json.jsonObject;
                            try {
                                JSONArray results = jsonObject.getJSONArray("results");
                                Log.i(TAG, "Results: " + results.toString());
                                videoGames.addAll(VideoGame.fromJsonArray(results));
                                videoGameAdapter.notifyDataSetChanged();
                                Log.i(TAG, "Video Games: " + videoGames.size());
                            } catch (JSONException e) {
                                Log.e(TAG, "Hit json exception", e);
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(int statusCode, Headers headers, String response, Throwable throwable) {
                            Log.d(TAG, "onFailure");
                        }
                    });
                    VIDEO_GAME_URL = "https://api.rawg.io/api/games?genres=" + caption + "&page=" + --page;
            }*/
            }

        });
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                while (page != 0){
                    client.get(VIDEO_GAME_URL, new JsonHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, Headers headers, JSON json) {
                            Log.d(TAG, "onSuccess");
                            JSONObject jsonObject = json.jsonObject;
                            try {
                                JSONArray results = jsonObject.getJSONArray("results");
                                Log.i(TAG, "Results: " + results.toString());
                                videoGames.addAll(VideoGame.fromJsonArray(results));
                                videoGameAdapter.notifyDataSetChanged();
                                Log.i(TAG, "Video Games: " + videoGames.size());
                            } catch (JSONException e) {
                                Log.e(TAG, "Hit json exception", e);
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(int statusCode, Headers headers, String response, Throwable throwable) {
                            Log.d(TAG, "onFailure");
                        }
                    });
                    if(caption != null)
                    VIDEO_GAME_URL = "https://api.rawg.io/api/games?genres=" + caption + "&page=" + --page;
                    else
                        VIDEO_GAME_URL = "https://api.rawg.io/api/games?page=" + --page;
                }
            }
        });
        /*client.get(VIDEO_GAME_URL, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Headers headers, JSON json) {
                Log.d(TAG, "onSuccess");
                JSONObject jsonObject = json.jsonObject;
                try {
                    JSONArray results = jsonObject.getJSONArray("results");
                    Log.i(TAG, "Results: " + results.toString());
                    videoGames.addAll(VideoGame.fromJsonArray(results));
                    videoGameAdapter.notifyDataSetChanged();
                    Log.i(TAG, "Video Games: " + videoGames.size());
                } catch (JSONException e) {
                    Log.e(TAG, "Hit json exception", e);
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Headers headers, String response, Throwable throwable) {
                Log.d(TAG, "onFailure");
            }
        });*/
        //VIDEO_GAME_URL = "https://api.rawg.io/api/games?page=" + page--;//}
    }

    private File getDataFile(){
        return new File(getContext().getFilesDir(), "data.txt");
    }





    /*protected void queryPosts() {
        // What class do I want to query? Posts!
        ParseQuery<Post> query = ParseQuery.getQuery(Post.class);
        query.include(Post.KEY_USER);
        query.setLimit(20);
        query.addDescendingOrder(Post.KEY_CREATED_AT);
        // Now to find the ID(s)
        query.findInBackground(new FindCallback<Post>() {
            @Override
            public void done(List<Post> posts, ParseException e) {
                if(e != null) {
                    Log.e(TAG, "I can't reach the posts!", e);
                    return;
                }
                for (Post post : posts) {
                    Log.i(TAG, "Post: " + post.getCaption() + ", and the user is: " + post.getUser().getUsername());
                }
                //adapter.clear();
                allPosts.addAll(posts);
                adapter.notifyDataSetChanged();
                swipeContainer.setRefreshing(false);
            }
        });
    }*/
}


